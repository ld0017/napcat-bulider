interface ThemeInfo {
  theme: ThemeConfig
  name: string
  description?: string
  author?: string
}
