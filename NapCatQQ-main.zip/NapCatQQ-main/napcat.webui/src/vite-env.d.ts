/// <reference types="vite/client" />

interface ImportMetaEnv {
  0
}

interface ImportMeta {
  readonly env: ImportMetaEnv
}
