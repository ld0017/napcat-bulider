export const napCatVersion = '4.6.0';
