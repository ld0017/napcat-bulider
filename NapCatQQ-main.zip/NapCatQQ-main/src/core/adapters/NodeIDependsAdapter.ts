/* eslint-disable @typescript-eslint/no-unused-vars */
import { MsfChangeReasonType, MsfStatusType } from '@/core/types/adapter';

export class NodeIDependsAdapter {
    onMSFStatusChange(_statusType: MsfStatusType, _changeReasonType: MsfChangeReasonType) {

    }

    onMSFSsoError(_args: unknown) {

    }

    getGroupCode(_args: unknown) {

    }
}
