/* eslint-disable @typescript-eslint/no-unused-vars */
export class NodeIDispatcherAdapter {
    dispatchRequest(_arg: unknown) {
    }

    dispatchCall(_arg: unknown) {
    }

    dispatchCallWithJson(_arg: unknown) {
    }
}
