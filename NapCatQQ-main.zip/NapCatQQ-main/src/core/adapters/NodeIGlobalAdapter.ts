/* eslint-disable @typescript-eslint/no-unused-vars */
export class NodeIGlobalAdapter {
    onLog(..._args: unknown[]) {
    }

    onGetSrvCalTime(..._args: unknown[]) {
    }

    onShowErrUITips(..._args: unknown[]) {
    }

    fixPicImgType(..._args: unknown[]) {
    }

    getAppSetting(..._args: unknown[]) {
    }

    onInstallFinished(..._args: unknown[]) {
    }

    onUpdateGeneralFlag(..._args: unknown[]) {
    }

    onGetOfflineMsg(..._args: unknown[]) {
    }
}
