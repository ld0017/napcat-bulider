export class NodeIKernelRecentContactListener {
    onDeletedContactsNotify(...args: unknown[]): any {

    }

    onRecentContactNotification(msgList: any, arg0: { msgListUnreadCnt: string }, arg1: number): any {

    }

    onMsgUnreadCountUpdate(...args: unknown[]): any {

    }

    onGuildDisplayRecentContactListChanged(...args: unknown[]): any {

    }

    onRecentContactListChanged(...args: unknown[]): any {

    }

    onRecentContactListChangedVer2(...args: unknown[]): any {

    }
}
