export class NodeIKernelRobotListener {
    onRobotFriendListChanged(...args: unknown[]): any {

    }

    onRobotListChanged(...args: unknown[]): any {

    }

    onRobotProfileChanged(...args: unknown[]): any {

    }
}
