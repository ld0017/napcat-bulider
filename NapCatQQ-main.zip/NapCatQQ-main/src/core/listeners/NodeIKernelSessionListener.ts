export class NodeIKernelSessionListener {
    onNTSessionCreate(args: unknown): any {

    }

    onGProSessionCreate(args: unknown): any {

    }

    onSessionInitComplete(args: unknown): any {

    }

    onOpentelemetryInit(info: { is_init: boolean, is_report: boolean }): any {

    }

    onUserOnlineResult(args: unknown): any {

    }

    onGetSelfTinyId(args: unknown): any {

    }
}
