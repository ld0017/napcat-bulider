export class NodeIKernelStorageCleanListener {
    onCleanCacheProgressChanged(args: unknown): any {

    }

    onScanCacheProgressChanged(args: unknown): any {

    }

    onCleanCacheStorageChanged(args: unknown): any {

    }

    onFinishScan(args: unknown): any {

    }

    onChatCleanDone(args: unknown): any {

    }
}
