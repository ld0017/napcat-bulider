export class NodeIKernelTicketListener {
    listener(): any {

    }
}
