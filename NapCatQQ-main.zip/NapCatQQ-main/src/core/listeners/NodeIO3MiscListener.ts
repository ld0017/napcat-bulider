export class NodeIO3MiscListener {
    getOnAmgomDataPiece(...arg: unknown[]): any {

    }
}