export enum MsfStatusType {
    KUNKNOWN = 0,
    KDISCONNECTED = 1,
    KCONNECTED = 2
}
export enum MsfChangeReasonType {
    KUNKNOWN = 0,
    KUSERLOGININ = 1,
    KUSERLOGINOUT = 2,
    KAUTO = 3
}