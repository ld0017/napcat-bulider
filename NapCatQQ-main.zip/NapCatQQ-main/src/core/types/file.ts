export interface rkeyDataType {
    private_rkey: string;
    group_rkey: string;
    online_rkey: boolean;
};